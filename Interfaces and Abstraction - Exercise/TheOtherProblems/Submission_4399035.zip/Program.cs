﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.Border_Control
{
    public class Program
    {
        public static void Main(string[] args)
        {
            List<IMigrant> migrants = new List<IMigrant>();

            var input = string.Empty;

            while ((input = Console.ReadLine()) != "End")
            {
                var tokens = input.Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries);

                if (tokens.Length == 2)
                {
                    migrants.Add(new Robot(tokens[1], tokens[0]));
                }
                else
                {
                    migrants.Add(new Citizen(tokens[2], tokens[0], int.Parse(tokens[1])));
                }
            }

            var endOfId = Console.ReadLine().Trim();


            foreach (var migrant in migrants)
            {
                if (migrant.Id.EndsWith(endOfId))
                {
                    Console.WriteLine(migrant.Id);
                }
            }
        }
    }
}
