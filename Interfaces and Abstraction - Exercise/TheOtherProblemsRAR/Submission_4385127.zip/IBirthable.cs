﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.Define_an_Interface_IPerson
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
